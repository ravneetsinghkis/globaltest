<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('product_catalogs', function (Blueprint $table) {
            $table->after('email',function($table){
                $table->string('establishment');
                $table->string('region');
                $table->string('representative_name');
                $table->string('representative_contact');
                $table->string('person_name');
                $table->string('person_info');       
            });
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('product_catalogs', function (Blueprint $table) {
            //
        });
    }
};
