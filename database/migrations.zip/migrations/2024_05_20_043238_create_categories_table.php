<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('categories', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->unsignedBigInteger('product_id');
            $table->enum('type', ['Distillery', 'Merchant', 'Brand']);
            $table->string('other_type');
            $table->string('brand_DM');
            $table->string('establishment');
            $table->string('country');
            $table->string('region');
            $table->string('story');
            $table->string('logo');
            $table->string('cover');      
            $table->string('socialmedia_link'); 
            $table->foreign('product_id')
            ->references('id')->on('product_catalogs')->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('categories');
    }
};
